# node-mysql-login-registration
simple login and registration tutorial with mysql


```js
cd node-mysql-login-registration-master
npm install
node app.js

install xampp
enable mysql with xaamp control panel
````

Disclaimer:
This is not production ready. Needs bcrypt and jwt tokens for login. Plus possibly google I am not a bot submission api to prevent bots. This is for tutorials purposes only. I do not offer any support for this code. You can use this code to learn and build small projects for fun. 
